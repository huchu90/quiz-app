# Quiz Challenge 프로젝트

## 프로젝트 개요
React 기반의 인터랙티브 퀴즈 게임 애플리케이션입니다.

## 기술 스택
- **프레임워크**: React 18 + Vite
- **상태관리**: React Hooks (useState, useCallback, useEffect, useRef)
- **컨텍스트**: React Context API (ThemeContext)
- **스타일링**: CSS (App.css)
- **저장소**: localStorage (LocalDataManager)

## 프로젝트 구조
```
quiz-app/
├── src/
│   ├── components/          # UI 컴포넌트
│   │   ├── StartScreen.jsx
│   │   ├── ModeSelectScreen.jsx
│   │   ├── CategorySelectScreen.jsx
│   │   ├── QuizScreen.jsx
│   │   ├── PauseScreen.jsx
│   │   ├── ResultScreen.jsx
│   │   ├── DashboardScreen.jsx
│   │   ├── LeaderboardScreen.jsx
│   │   └── SettingsScreen.jsx
│   ├── hooks/
│   │   └── useQuiz.js       # 게임 로직 훅
│   ├── utils/
│   │   ├── ScoreManager.js  # 점수 계산
│   │   ├── gameModes.js     # 게임 모드 설정
│   │   └── LocalDataManager.js  # localStorage 관리
│   ├── contexts/
│   │   └── ThemeContext.jsx # 다크모드 컨텍스트
│   ├── data/
│   │   └── questions.js     # 퀴즈 문제 데이터 (80문제)
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
```

## 주요 기능
1. **게임 모드**: 전체(40문제), 카테고리(10문제), 스피드(20문제/15초)
2. **카테고리**: 한국사, 과학, 지리, 일반상식
3. **점수 시스템**: 기본점수 + 시간보너스 + 노힌트보너스 + 콤보보너스
4. **힌트**: 오답 2개 제거 (모드별 사용 횟수 제한)
5. **리더보드**: 전체/주간/일일 순위
6. **통계 대시보드**: 정답률, 카테고리별 성적, 점수 추이
7. **다크모드**: 설정에서 토글 가능
8. **데이터 관리**: 내보내기/가져오기, 초기화

## 개발 가이드라인

### 코드 스타일
- 함수형 컴포넌트 + Hooks 사용
- 컴포넌트당 하나의 파일
- props는 구조분해 할당으로 받기

### 상태 관리
- 게임 상태는 useQuiz 훅에서 중앙 관리
- 전역 설정(테마)은 Context 사용
- 영구 저장은 LocalDataManager 통해 localStorage 사용

## 퀴즈 문제 작성 가이드라인

### 필수 확인 사항
1. **정답 유일성**: 다른 해석 가능 시 조건 명시
2. **기준 명시**: '가장 큰', '최초의' 등 최상급 표현에 측정 기준 포함
3. **시점 명시**: 변할 수 있는 정보는 연도/시점 명시
4. **범위 한정**: 지리적, 분류적 범위 명확히

### 문제 구조
```javascript
{
  id: number,
  category: "한국사" | "과학" | "지리" | "일반상식",
  difficulty: "easy" | "medium" | "hard",
  question: string,
  options: string[4],
  correctAnswer: 0 | 1 | 2 | 3,
  explanation: string
}
```

### 논란 방지 예시
- (X) "세계에서 가장 긴 강은?"
- (O) "전통적으로 세계에서 가장 긴 강으로 인정받는 강은?"

## 빌드 및 실행
```bash
cd quiz-app
npm install
npm run dev    # 개발 서버
npm run build  # 프로덕션 빌드
```

## 버전
- v2.0: 점수 시스템, 게임 모드, 힌트, 타이머
- v3.0: 리더보드, 대시보드, 다크모드, 80문제 확장, 공유 기능


퀴즈 문제 교차 검증 가이드라인
모든 문제 작성 시 확인 사항
1. 정답이 하나뿐인가?
- 다른 해석 가능 시 조건 명시 (예: 면적 기준, 2024년 기준)
2. 최상급 표현에 기준이 있는가?
- ‘가장 큰’, ‘최초의’ 등 표현에 측정 기준 명시
3. 시간과 범위가 명확한가?
- 변할 수 있는 정보는 시점 명시
- 지리적, 분류적 범위 한정
4. 교차 검증했는가?
- 의심스러운 정보는 2개 이상 출처 확인
- 논란 있는 내용은 주류 학설 기준
